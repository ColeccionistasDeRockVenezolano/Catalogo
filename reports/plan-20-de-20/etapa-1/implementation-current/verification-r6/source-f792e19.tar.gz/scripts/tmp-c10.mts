import { closeDb, getPool } from "../src/db/client.js";
for (const id of process.argv.slice(2).map(Number)) {
  const p = (await getPool().query(`SELECT name, birth_date, death_date FROM public.persons WHERE id=$1`, [id])).rows[0];
  const rows = (await getPool().query(`
    SELECT ar.name, min(a.release_year) y0, max(a.release_year) y1, string_agg(DISTINCT c.role, '; ') roles, string_agg(DISTINCT c.credited, ' | ') cred FROM (
      SELECT album_id, role, NULL::text credited FROM public.album_credits WHERE person_id=$1 UNION ALL
      SELECT t.album_id, tc.role, NULL::text FROM public.track_credits tc JOIN public.tracks t ON t.id=tc.track_id WHERE tc.person_id=$1) c
    JOIN public.albums a ON a.id=c.album_id JOIN public.artists ar ON ar.id=a.artist_id GROUP BY 1 ORDER BY 2`, [id])).rows;
  console.log(`\n## ${id} ${p?.name} (${p?.birth_date ?? ""}–${p?.death_date ?? ""})`);
  for (const r of rows) console.log(`  ${r.name} ${r.y0}-${r.y1}: ${String(r.roles).slice(0, 80)} [${r.cred ?? ""}]`);
}
await closeDb();
