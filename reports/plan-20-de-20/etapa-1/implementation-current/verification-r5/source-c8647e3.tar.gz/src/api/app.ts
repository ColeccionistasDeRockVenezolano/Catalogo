// CRV · API Fastify (ARCHITECTURE.md §4.14, PHASES §E7A lectura + §E7B escritura).
// Browser -> API -> PostgreSQL (CONTRACT #20): esta app es el único punto
// por el que el navegador puede llegar a los datos. La lectura es abierta; la
// escritura exige el token del operador y pasa por el merge engine como
// claims human/high (src/merge/operator.ts), nunca por SQL en los controllers.
import Fastify, { type FastifyInstance } from "fastify";
import { warmSearchIndex } from "./search-index.js";
import cors from "@fastify/cors";
import swagger from "@fastify/swagger";
import swaggerUi from "@fastify/swagger-ui";
import {
  serializerCompiler,
  validatorCompiler,
  jsonSchemaTransform,
  type ZodTypeProvider,
} from "fastify-type-provider-zod";
import { moduleLogger } from "../logger/index.js";
import { getEnv } from "../config/env.js";
import { toApiError } from "./http-errors.js";
import { registerOperatorAuth } from "./auth.js";
import { registerHealthRoutes } from "./routes/health.js";
import { registerDiscoveryRoutes } from "./routes/discovery.js";
import { registerTrackContextRoutes } from "./routes/track-contexts.js";
import { registerRecommendationRoutes } from "./routes/recommendations.js";
import { registerSearchRoutes } from "./routes/search.js";
import { registerArtistRoutes } from "./routes/artists.js";
import { registerAlbumRoutes } from "./routes/albums.js";
import { registerGenreRoutes } from "./routes/genres.js";
import { registerTrackRoutes } from "./routes/tracks.js";
import { registerPersonRoutes } from "./routes/persons.js";
import { registerOrganizationRoutes } from "./routes/organizations.js";
import { registerSourceRoutes } from "./routes/sources.js";
import { registerReviewRoutes } from "./routes/review-queue.js";
import { registerYouTubeRoutes } from "./routes/youtube.js";
import { registerCatalogWriteRoutes } from "./routes/catalog-writes.js";
import { registerPlatformLinkRoutes } from "./routes/platform-links.js";
import { registerRelationWriteRoutes } from "./routes/relation-writes.js";
import { registerEntityMergeRoutes } from "./routes/entity-merge.js";
import { registerPersonCandidateRoutes } from "./routes/person-candidates.js";
import { registerMergeRunRoutes } from "./routes/merge-runs.js";
import { registerAliasRoutes } from "./routes/aliases.js";
import { registerAuditRoutes } from "./routes/audit.js";
import { registerChangeRoutes } from "./routes/changes.js";
import { registerCurationRoutes } from "./routes/curation.js";
import { registerCurationActionRoutes } from "./routes/curation-actions.js";
import { registerCurationAutofixRoutes } from "./routes/curation-autofix.js";
import { registerImageCandidateRoutes } from "./routes/image-candidates.js";
import { registerEntityComparisonRoutes } from "./routes/entity-comparison.js";
import { registerEntityVerificationRoutes } from "./routes/entity-verification.js";
import { installAutofix } from "../curation/autofix.js";
import { registerAiCurationRoutes } from "./routes/ai-curation.js";
import { registerEvidenceInventoryRoutes } from "./routes/evidence-inventory.js";

const log = moduleLogger("api");

export async function buildApp(): Promise<FastifyInstance> {
  // Fastify trae Pino integrado (ARCHITECTURE.md §6: "JSON a stdout"); no se
  // inyecta la instancia propia de src/logger para evitar el desajuste de
  // tipos entre FastifyBaseLogger y pino.Logger bajo exactOptionalPropertyTypes.
  // El serializador por defecto de `req` no incluye cabeceras: el token no llega a los logs.
  const app = Fastify({
    logger: {
      level: getEnv().LOG_LEVEL,
      redact: {
        paths: ["req.headers.authorization", "req.headers.cookie", "res.headers['set-cookie']"],
        censor: "[REDACTED]",
      },
    },
  }).withTypeProvider<ZodTypeProvider>();

  app.setValidatorCompiler(validatorCompiler);
  app.setSerializerCompiler(serializerCompiler);

  // origin:true + credentials:true reflejaría cualquier origen con permiso
  // de mandar cookies: cualquier sitio podría leer /auth/me (csrf incluido)
  // desde el navegador de un colaborador. Solo se permiten los orígenes
  // declarados (dev incluido); la comprobación fina por-mismo-host para
  // producción vive en auth.ts (isTrustedOrigin) y no depende de esto.
  await app.register(cors, {
    origin: getEnv().CRV_ALLOWED_ORIGINS.split(",").map((item) => item.trim()).filter(Boolean),
    credentials: true,
    // Sin esta lista, @fastify/cors solo anuncia GET/HEAD/POST y el navegador
    // bloquea en el preflight TODA edición (PATCH/DELETE) desde un origen
    // declarado distinto del de la API — pasó con el QA de administración
    // (2026-09-18): la web de desarrollo no podía guardar nada.
    methods: ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE"],
    allowedHeaders: ["content-type", "authorization", "x-crv-operator", "x-crv-csrf"],
  });

  await app.register(swagger, {
    openapi: {
      info: {
        title: "Coleccionistas de Rock Venezolano — API",
        description: "Catálogo: lectura abierta (PHASES §E7A) y escritura del operador a través del merge engine (§E7B). "
          + "El navegador nunca conecta a PostgreSQL directamente.",
        version: "0.2.0",
      },
      components: {
        securitySchemes: {
          collaboratorSession: {
            type: "apiKey",
            in: "cookie",
            name: "crv_session",
            description: "Sesión HttpOnly creada por POST /auth/login; las escrituras exigen además X-CRV-CSRF.",
          },
          operatorToken: {
            type: "http",
            scheme: "bearer",
            description: "Bearer legado para automatizaciones internas. La interfaz web usa collaboratorSession.",
          },
        },
      },
    },
    transform: jsonSchemaTransform,
  });
  await app.register(swaggerUi, { routePrefix: "/docs" });

  app.setErrorHandler((error: Error, _request, reply) => {
    const expected = toApiError(error);
    if (expected) {
      reply.status(expected.statusCode).send({
        error: { code: expected.code, message: expected.message, ...(expected.details === undefined ? {} : { details: expected.details }) },
      });
      return;
    }
    // Errores de validación Zod ya vienen serializados por fastify-type-provider-zod
    // con statusCode; el resto es un fallo real que se registra y no se disfraza.
    const statusCode = (error as { statusCode?: number }).statusCode;
    if (statusCode !== undefined && statusCode < 500) {
      reply.status(statusCode).send({ error: { code: "bad_request", message: error.message } });
      return;
    }
    log.error({ err: error }, "error no controlado en la API");
    reply.status(500).send({ error: { code: "internal_error", message: "error interno" } });
  });

  app.setNotFoundHandler((request, reply) => {
    reply.status(404).send({ error: { code: "not_found", message: `ruta inexistente: ${request.method} ${request.url}` } });
  });

  await registerOperatorAuth(app);
  await registerHealthRoutes(app);
  await registerSearchRoutes(app);
  await registerDiscoveryRoutes(app);
  await registerTrackContextRoutes(app);
  await registerRecommendationRoutes(app);
  await registerArtistRoutes(app);
  await registerAlbumRoutes(app);
  await registerGenreRoutes(app);
  await registerTrackRoutes(app);
  await registerPersonRoutes(app);
  await registerOrganizationRoutes(app);
  await registerSourceRoutes(app);
  await registerReviewRoutes(app);
  await registerYouTubeRoutes(app);
  await registerCatalogWriteRoutes(app);
  await registerRelationWriteRoutes(app);
  await registerPlatformLinkRoutes(app);
  await registerEntityMergeRoutes(app);
  await registerPersonCandidateRoutes(app);
  await registerMergeRunRoutes(app);
  await registerAliasRoutes(app);
  await registerAuditRoutes(app);
  await registerChangeRoutes(app);
  await registerCurationRoutes(app);
  await registerCurationActionRoutes(app);
  await registerCurationAutofixRoutes(app);
  await registerImageCandidateRoutes(app);
  await registerEntityVerificationRoutes(app);
  await registerEntityComparisonRoutes(app);
  await registerAiCurationRoutes(app);
  await registerEvidenceInventoryRoutes(app);
  // La autocorrección se engancha al final de cada análisis completo. Sigue
  // apagada mientras CRV_CURATION_AUTOFIX sea false y no haya reglas encendidas.
  installAutofix();

  // El índice de búsqueda (E11.9) se carga en segundo plano: la primera
  // búsqueda real no debe pagar la lectura completa de nombres y alias.
  void warmSearchIndex((error) => { app.log.error({ err: error }, "no se pudo calentar el índice de búsqueda"); });

  return app;
}
