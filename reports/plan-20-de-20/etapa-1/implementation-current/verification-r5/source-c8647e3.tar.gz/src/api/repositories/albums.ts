// CRV · Consultas de lectura para discos (PHASES §E7A: "ALBUM DETAIL... una
// de las páginas más importantes"). La ficha agregada trae tracklist,
// créditos (planos y agrupados por credit_type), formatos, alias y enlaces
// de YouTube en una sola consulta.
import { genreStatusOf, type GenreStatus } from "../../merge/genre-projection.js";
import { getPool } from "../../db/client.js";
import { genreFilterSql, genreMissingSql, publicGenresFor, relatedGenreFilterSql, type PublicGenre } from "../../genres/public.js";
import type { PaginationQuery } from "../pagination.js";

export interface AlbumListRow {
  id: number;
  title: string;
  releaseYear: number | null;
  albumType: string;
  artistId: number;
  artistName: string;
  coverUrl: string | null;
  primaryGenre: PublicGenre | null;
  genreStatus: GenreStatus;
  /** Tiene al menos un género confirmado propio (con `relatedGenre`, los que no lo tienen entraron por su artista). */
  hasOwnGenre: boolean;
}

export interface AlbumListQuery extends PaginationQuery {
  q?: string | undefined;
  artistId?: number | undefined;
  /** Slug de género o familia (PLAN_GENEROS §5): solo asignaciones confirmadas. */
  genre?: string | undefined;
  /** Solo discos sin ningún género confirmado. */
  withoutGenre?: boolean | undefined;
  /** Con `genre`: suma los discos sin género propio cuyo artista tiene ese género. */
  relatedGenre?: boolean | undefined;
  decade?: number | undefined;
  withoutYear?: boolean | undefined;
  albumType?: string | undefined;
}

export async function listAlbums(query: AlbumListQuery): Promise<{ rows: AlbumListRow[]; total: number }> {
  const pattern = query.q ? `%${query.q}%` : null;
  // $1 título · $2 artista · $3 género · $4 década · $5 tipo de lanzamiento
  // $6 solo sin género · $7 sumar por el género del artista
  const filters = `($1::text IS NULL OR al.title ILIKE $1)
          AND ($2::bigint IS NULL OR al.artist_id = $2)
          AND ($3::text IS NULL OR ${genreFilterSql("album", "al.id", "$3")}
               OR ($7::boolean AND ${genreMissingSql("album", "al.id")} AND ${relatedGenreFilterSql("al.id", "$3")}))
          AND ($4::int IS NULL OR (al.release_year >= $4 AND al.release_year < $4 + 10))
          AND ($5::text IS NULL OR al.album_type::text = $5)
          AND (NOT $6::boolean OR ${genreMissingSql("album", "al.id")})
          AND (NOT $8::boolean OR al.release_year IS NULL)`;
  const params = [pattern, query.artistId ?? null, query.genre ?? null, query.decade ?? null, query.albumType ?? null,
    query.withoutGenre ?? false, query.relatedGenre ?? false, query.withoutYear ?? false];
  const [rows, count] = await Promise.all([
    getPool().query<{
      id: string; title: string; release_year: number | null; album_type: string;
      artist_id: string; artist_name: string; cover_url: string | null; genre: string | null;
    }>(
      `SELECT al.id, al.title, al.release_year, al.album_type, ar.id AS artist_id, ar.name AS artist_name, al.cover_url, al.genre
         FROM public.albums al
         JOIN public.artists ar ON ar.id = al.artist_id
        WHERE ${filters}
        ORDER BY al.title
        LIMIT $9 OFFSET $10`,
      [...params, query.limit, query.offset],
    ),
    getPool().query<{ count: string }>(
      `SELECT count(*)::text AS count FROM public.albums al WHERE ${filters}`,
      params,
    ),
  ]);
  const genres = await publicGenresFor("album", rows.rows.map((row) => Number(row.id)),
    new Map(rows.rows.map((row) => [Number(row.id), row.genre])));
  return {
    rows: rows.rows.map((row) => ({
      id: Number(row.id), title: row.title, releaseYear: row.release_year, albumType: row.album_type,
      artistId: Number(row.artist_id), artistName: row.artist_name, coverUrl: row.cover_url,
      primaryGenre: genres.get(Number(row.id))?.primaryGenre ?? null,
      genreStatus: genres.get(Number(row.id))?.genreStatus ?? "unclassified",
      hasOwnGenre: (genres.get(Number(row.id))?.genres.length ?? 0) > 0,
    })),
    total: Number(count.rows[0]?.count ?? 0),
  };
}

export interface AlbumCreditRow {
  id: number;
  creditType: string;
  role: string;
  personId: number | null;
  personName: string | null;
  personIsDeceased: boolean;
  artistId: number | null;
  artistName: string | null;
  organizationId: number | null;
  organizationName: string | null;
}

/** Un mismo crédito repetido en varias pistas del disco, visto desde el disco. */
export interface ScopedCreditRow extends AlbumCreditRow {
  creditIds: number[];
  tracks: Array<{ discNumber: number; trackNumber: number }>;
}

export interface AlbumTrackRow {
  notes: string | null;
  id: number;
  discNumber: number;
  trackNumber: number;
  title: string;
  durationSeconds: number | null;
  youtubeStartSeconds: number | null;
  credits: AlbumCreditRow[];
}

export interface AlbumDetail {
  releaseDateText: string | null;
  catalogId: string | null;
  mediaFormat: string | null;
  id: number;
  title: string;
  releaseYear: number | null;
  albumType: string;
  genre: string | null;
  /** `confirmed` (principal confirmado), `pending` (texto de fuente sin confirmar) o `unclassified` (PLAN_GENEROS §5). */
  genreStatus: GenreStatus;
  /** Principal confirmado y todos los confirmados (PLAN_GENEROS §5); nunca sugerencias. */
  primaryGenre: PublicGenre | null;
  genres: PublicGenre[];
  coverUrl: string | null;
  description: string | null;
  notes: string | null;
  youtubeUrl: string | null;
  youtubeStatus: string;
  instagramUrl: string | null;
  instagramStatus: string;
  wordpressUrl: string | null;
  wordpressStatus: string;
  artist: { id: number; name: string };
  label: { id: number; name: string } | null;
  tracklist: AlbumTrackRow[];
  credits: AlbumCreditRow[];
  creditsByType: Record<string, AlbumCreditRow[]>;
  /**
   * Créditos de pista agrupados por acreditado, tipo y rol: "Keyboards ·
   * pistas 1, 3, 5, 10". Un invitado del canal casi siempre viene acotado a
   * pistas y, sin esto, no aparecía en la sección del disco.
   */
  scopedCreditsByType: Record<string, ScopedCreditRow[]>;
  formats: Array<{ id: number; format: string; quality: string | null; archiveStatus: string; filePath: string | null; notes: string | null }>;
  aliases: Array<{ id: number; alias: string; aliasType: string; isPrimary: boolean }>;
  youtubeLinks: Array<{ videoId: string; title: string | null; kind: string; isPrimaryLink: boolean }>;
  /** El disco en plataformas de escucha (streaming_links, 0039); solo los de identidad verificada. */
  platforms: Array<{ platform: string; url: string }>;
}

const CREDIT_FIELDS = `jsonb_build_object(
    'id', id, 'creditType', credit_type, 'role', role,
    'personId', person_id, 'personName', person_name, 'personIsDeceased', person_is_deceased,
    'artistId', artist_id, 'artistName', artist_name,
    'organizationId', organization_id, 'organizationName', organization_name
  )`;

function creditKey(credit: AlbumCreditRow): string {
  const target = credit.personId !== null ? `p${credit.personId}` : credit.artistId !== null ? `a${credit.artistId}` : `o${credit.organizationId}`;
  return `${credit.creditType}|${credit.role.trim().toLowerCase()}|${target}`;
}

/** Agrupa los créditos de pista; lo que ya está acreditado en el disco entero no se repite. */
export function scopedCreditsByType(tracklist: AlbumTrackRow[], albumCredits: AlbumCreditRow[]): Record<string, ScopedCreditRow[]> {
  const albumWide = new Set(albumCredits.map(creditKey));
  const grouped = new Map<string, ScopedCreditRow>();
  for (const track of tracklist) {
    for (const credit of track.credits) {
      const key = creditKey(credit);
      if (albumWide.has(key)) continue;
      const entry = grouped.get(key) ?? { ...credit, creditIds: [], tracks: [] };
      entry.creditIds.push(credit.id);
      entry.tracks.push({ discNumber: track.discNumber, trackNumber: track.trackNumber });
      grouped.set(key, entry);
    }
  }
  const byType: Record<string, ScopedCreditRow[]> = {};
  for (const entry of grouped.values()) (byType[entry.creditType] ??= []).push(entry);
  return byType;
}

export async function getAlbumDetail(id: number): Promise<AlbumDetail | null> {
  const { rows } = await getPool().query<Record<string, unknown>>(
    `SELECT al.id, al.title, al.release_year, al.album_type, al.genre, al.cover_url,
            al.description, al.notes, al.release_date_text, al.catalog_id, al.media_format, al.youtube_url, al.youtube_status,
            al.instagram_url, al.instagram_status, al.wordpress_url, al.wordpress_status,
            ar.id AS artist_id, ar.name AS artist_name,
            lbl.id AS label_id, lbl.name AS label_name,
            EXISTS (SELECT 1 FROM ingest.album_genres ag
                     WHERE ag.album_id = al.id AND ag.role = 'primary' AND ag.status = 'confirmed') AS genre_confirmed,
       COALESCE((
         SELECT jsonb_agg(jsonb_build_object(
           'id', t.id, 'discNumber', t.disc_number, 'trackNumber', t.track_number,
           'title', t.title, 'durationSeconds', t.duration_seconds,
           'youtubeStartSeconds', t.youtube_start_seconds, 'notes', t.notes,
           'credits', COALESCE((
             SELECT jsonb_agg(${CREDIT_FIELDS})
             FROM (
               SELECT tc.id, tc.credit_type, tc.role, tc.person_id, tcp.name AS person_name,
                      COALESCE(tcp.is_deceased, false) OR tcp.death_date IS NOT NULL AS person_is_deceased,
                      tc.artist_id, tca.name AS artist_name, tc.organization_id, tco.name AS organization_name
                 FROM public.track_credits tc
                 LEFT JOIN public.persons tcp ON tcp.id = tc.person_id
                 LEFT JOIN public.artists tca ON tca.id = tc.artist_id
                 LEFT JOIN public.organizations tco ON tco.id = tc.organization_id
                WHERE tc.track_id = t.id
             ) credit_rows
           ), '[]'::jsonb)
         ) ORDER BY t.disc_number, t.track_number)
         FROM public.tracks t WHERE t.album_id = al.id
       ), '[]'::jsonb) AS tracklist,
       COALESCE((
         SELECT jsonb_agg(${CREDIT_FIELDS})
         FROM (
           SELECT ac.id, ac.credit_type, ac.role, ac.person_id, acp.name AS person_name,
                  COALESCE(acp.is_deceased, false) OR acp.death_date IS NOT NULL AS person_is_deceased,
                  ac.artist_id, aca.name AS artist_name, ac.organization_id, aco.name AS organization_name
             FROM public.album_credits ac
             LEFT JOIN public.persons acp ON acp.id = ac.person_id
             LEFT JOIN public.artists aca ON aca.id = ac.artist_id
             LEFT JOIN public.organizations aco ON aco.id = ac.organization_id
            WHERE ac.album_id = al.id
         ) credit_rows
       ), '[]'::jsonb) AS credits,
       COALESCE((
         SELECT jsonb_agg(jsonb_build_object('id', f.id, 'format', f.format, 'quality', f.quality, 'archiveStatus', f.archive_status, 'filePath', f.file_path, 'notes', f.notes))
         FROM public.album_formats f WHERE f.album_id = al.id
       ), '[]'::jsonb) AS formats,
       COALESCE((
         SELECT jsonb_agg(jsonb_build_object('id', x.id, 'alias', x.alias, 'aliasType', x.alias_type, 'isPrimary', x.is_primary))
         FROM ingest.album_aliases x WHERE x.album_id = al.id
       ), '[]'::jsonb) AS aliases,
       COALESCE((
         SELECT jsonb_agg(jsonb_build_object(
           'videoId', v.video_id, 'title', v.title, 'kind', va.album_kind, 'isPrimaryLink', va.is_primary_link
         ) ORDER BY va.is_primary_link DESC, v.published_at)
         FROM media.video_albums va JOIN media.youtube_videos v ON v.id = va.video_id
         WHERE va.album_id = al.id
       ), '[]'::jsonb) AS youtube_links,
       COALESCE((
         SELECT jsonb_agg(jsonb_build_object('platform', sl.platform, 'url', sl.url) ORDER BY sl.platform)
           FROM public.streaming_links sl WHERE sl.album_id = al.id AND sl.verified
       ), '[]'::jsonb) AS platforms
     FROM public.albums al
     JOIN public.artists ar ON ar.id = al.artist_id
     LEFT JOIN public.organizations lbl ON lbl.id = al.label_id
     WHERE al.id = $1`,
    [id],
  );
  const row = rows[0];
  if (!row) return null;
  const credits = row["credits"] as AlbumCreditRow[];
  const creditsByType: Record<string, AlbumCreditRow[]> = {};
  for (const credit of credits) {
    (creditsByType[credit.creditType] ??= []).push(credit);
  }
  const tracklist = row["tracklist"] as AlbumTrackRow[];
  const genres = (await publicGenresFor("album", [id], new Map([[id, row["genre"] as string | null]]))).get(id)!;
  return {
    id: Number(row["id"]),
    title: row["title"] as string,
    releaseYear: row["release_year"] as number | null,
    releaseDateText: row["release_date_text"] as string | null,
    catalogId: row["catalog_id"] as string | null,
    mediaFormat: row["media_format"] as string | null,
    albumType: row["album_type"] as string,
    genre: row["genre"] as string | null,
    genreStatus: genreStatusOf(row["genre_confirmed"] === true, row["genre"] as string | null),
    primaryGenre: genres.primaryGenre,
    genres: genres.genres,
    coverUrl: row["cover_url"] as string | null,
    description: row["description"] as string | null,
    notes: row["notes"] as string | null,
    youtubeUrl: row["youtube_url"] as string | null,
    youtubeStatus: row["youtube_status"] as string,
    instagramUrl: row["instagram_url"] as string | null,
    instagramStatus: row["instagram_status"] as string,
    wordpressUrl: row["wordpress_url"] as string | null,
    wordpressStatus: row["wordpress_status"] as string,
    artist: { id: Number(row["artist_id"]), name: row["artist_name"] as string },
    label: row["label_id"] != null ? { id: Number(row["label_id"]), name: row["label_name"] as string } : null,
    tracklist,
    credits,
    creditsByType,
    scopedCreditsByType: scopedCreditsByType(tracklist, credits),
    formats: row["formats"] as AlbumDetail["formats"],
    aliases: row["aliases"] as AlbumDetail["aliases"],
    youtubeLinks: row["youtube_links"] as AlbumDetail["youtubeLinks"],
    platforms: row["platforms"] as AlbumDetail["platforms"],
  };
}
